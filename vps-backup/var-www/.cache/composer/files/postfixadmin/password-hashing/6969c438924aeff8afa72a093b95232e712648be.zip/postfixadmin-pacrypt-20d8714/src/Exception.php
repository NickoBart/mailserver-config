<?php

namespace PostfixAdmin\PasswordHashing;

class Exception extends \Exception
{
}
