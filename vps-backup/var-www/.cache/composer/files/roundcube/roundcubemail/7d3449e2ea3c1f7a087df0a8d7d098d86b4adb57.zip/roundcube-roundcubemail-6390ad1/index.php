<?php

exit('Please, configure your HTTP server to point to the /public_html directory (with fallback to /public_html/index.php.');
