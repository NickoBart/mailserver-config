\$caching\_type {#variable.caching.type}
===============

This property specifies the name of the caching handler to use. It
defaults to `file`, enabling the internal filesystem based cache
handler.

See [Custom Cache Implementation](#caching.custom) for pointers on
setting up your own cache handler.
