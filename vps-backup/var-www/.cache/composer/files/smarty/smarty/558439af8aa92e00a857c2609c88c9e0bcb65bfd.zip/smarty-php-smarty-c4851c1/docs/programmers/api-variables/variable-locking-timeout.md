\$locking\_timeout {#variable.locking.timeout}
==================

This is maximum time in seconds a cache lock is valid to avoid dead
locks. The default value is 10 seconds.

See also [`$cache_locking`](#variable.cache.locking)
