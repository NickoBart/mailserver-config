\$left\_delimiter {#variable.left.delimiter}
=================

This is the left delimiter used by the template language. Default is
`{`.

See also [`$right_delimiter`](#variable.right.delimiter) and [escaping
smarty parsing](#language.escaping) .
