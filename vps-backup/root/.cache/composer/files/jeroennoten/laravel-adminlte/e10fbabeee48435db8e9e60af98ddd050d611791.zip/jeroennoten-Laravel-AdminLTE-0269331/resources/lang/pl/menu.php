<?php

return [

    'main_navigation' => 'GŁÓWNA NAWIGACJA',
    'blog' => 'Blog',
    'pages' => 'Strony',
    'account_settings' => 'USTAWIENIA KONTA',
    'profile' => 'Profil',
    'change_password' => 'Zmień hasło',
    'multilevel' => 'Wielopoziomowe',
    'level_one' => 'Poziom 1',
    'level_two' => 'Poziom 2',
    'level_three' => 'Poziom 3',
    'labels' => 'ETYKIETY',
    'important' => 'Ważne',
    'warning' => 'Ostrzeżenie',
    'information' => 'Informacja',
];
