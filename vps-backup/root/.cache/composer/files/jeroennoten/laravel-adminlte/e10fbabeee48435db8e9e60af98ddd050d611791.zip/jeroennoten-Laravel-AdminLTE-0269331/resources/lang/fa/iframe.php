<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'بستن',
    'btn_close_active' => 'بستن فعال',
    'btn_close_all' => 'بستن همه',
    'btn_close_all_other' => 'بستن همه چیز دیگر',
    'tab_empty' => 'هیچ تب ای انتخاب نشده است',
    'tab_home' => 'خانه',
    'tab_loading' => 'تب در حال بارگیری است',
];
