<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Cerrar',
    'btn_close_active' => 'Cerrar Activa',
    'btn_close_all' => 'Cerrar Todas',
    'btn_close_all_other' => 'Cerrar Las Demás',
    'tab_empty' => 'Ninguna pestaña seleccionada!',
    'tab_home' => 'Inicio',
    'tab_loading' => 'Cargando pestaña',

];
